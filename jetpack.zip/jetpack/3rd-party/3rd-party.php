<?php

/*
 * Placeholder to load 3rd party plugin tweaks until a legit system
 * is architected
 */

require_once( 'buddypress.php' );
require_once( 'wpml.php' );